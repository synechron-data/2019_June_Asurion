
// import React from 'react';
// import ReactDOM from 'react-dom';
// import HelloComponent from './components/HelloComponent';
// import ComponentOne from './components/multi-components/ComponentOne';
// import ComponentTwo from './components/multi-components/ComponentTwo';

// ReactDOM.render(<HelloComponent />, document.getElementById('root'));

// var r1 = ReactDOM.render(<ComponentOne />, document.getElementById('root1'));

// var r2 = ReactDOM.render(<ComponentTwo />, document.getElementById('root2'));

// console.log(r1);
// console.log(r2);

// ReactDOM.render(<React.Fragment>
//     <ComponentOne/> 
//     <ComponentTwo/>
// </React.Fragment>, document.getElementById('root'));

import React from 'react';
import ReactDOM from 'react-dom';
import RootComponent from './components/RootComponent';

// ----------------------- including Bootstrap 3
// npm install --save bootstrap@3 jquery
// import $ from 'jquery';
// import 'bootstrap/dist/css/bootstrap.css';

// window.$ = $;
// window.jQuery = $;
// global.jQuery = $;

// // eslint-disable-next-line
// const bootstrap = require('bootstrap');

// ------------------------ including Bootstrap 4
// npm install --save bootstrap popper.js
// npm install --save-dev node-sass

import $ from 'jquery';
import 'bootstrap/scss/bootstrap.scss';

window.$ = $;
window.jQuery = $;
global.jQuery = $;

// eslint-disable-next-line
const bootstrap = require('bootstrap');

ReactDOM.render(<RootComponent />, document.getElementById('root'));