// import React from 'react';

// const StatelessComponent = (props) => {
//     console.log("StatelessComponent -", this);
//     console.log("StatelessComponent -", props);
//     return (
//         <div>
//             <h2>StatelessComponent - {props.name}</h2> 
//         </div>
//     );
// };

// export default StatelessComponent;

// import React from 'react';

// const StatelessComponent = ({name, empNumber}) => {
//     console.log("StatelessComponent -", name);
//     console.log("StatelessComponent -", empNumber);
//     return (
//         <div>
//             <h2>StatelessComponent - {name}</h2> 
//         </div>
//     );
// };

// export default StatelessComponent;


import React from 'react';

const StatelessComponent = ({name, empNumber, ...address}) => {
    console.log("StatelessComponent -", name);
    console.log("StatelessComponent -", empNumber);
    console.log("StatelessComponent -", address);
    return (
        <div>
            <h2>StatelessComponent - {name}</h2> 
        </div>
    );
};

export default StatelessComponent;