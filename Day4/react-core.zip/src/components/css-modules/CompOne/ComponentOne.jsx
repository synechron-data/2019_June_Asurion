import React from 'react';
import styles from './ComponentOne.module.css';

const ComponentOne = () => {
    return (
        <h2 className={`text-success ${styles.mycard}`}>Hi From Component One</h2>
    );
}

export default ComponentOne;