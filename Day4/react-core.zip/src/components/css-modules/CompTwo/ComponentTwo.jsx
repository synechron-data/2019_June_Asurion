import React from 'react';
import styles from './ComponentTwo.module.css';

const ComponentTwo = () => {
    return (
        <React.Fragment>
            <h2 className={`text-info ${styles.mycard}`}>Hi From Component Two</h2>
            <h2 className={styles.mycard}>Hi From Component Two</h2>
        </React.Fragment>
    );
}

export default ComponentTwo;