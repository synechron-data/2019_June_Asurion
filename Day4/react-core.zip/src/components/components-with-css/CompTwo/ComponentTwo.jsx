// import React from 'react';

// const ComponentTwo = () => {
//     const card2 = {
//         margin: '1em',
//         paddingLeft: 0,
//         border: '2px dashed blue'
//     };

//     return (
//         <h2 style={card2} className="text-info">Hi From Component Two</h2>
//     );
// }

// export default ComponentTwo;


import React from 'react';
import './ComponentTwo.css';

const ComponentTwo = () => {
    return (
        <h2 className="text-info card2">Hi From Component Two</h2>
    );
}

export default ComponentTwo;