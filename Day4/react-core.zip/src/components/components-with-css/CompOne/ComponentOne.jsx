// import React from 'react';

// const ComponentOne = () => {
//     const card1 = {
//         margin: '1em',
//         paddingLeft: 0,
//         border: '2px solid green' 
//     };

//     return (
//         <h2 style={card1} className="text-success">Hi From Component One</h2>
//     );
// }

// export default ComponentOne;

import React from 'react';
import './ComponentOne.css';

const ComponentOne = () => {
    return (
        <h2 className="text-success card1">Hi From Component One</h2>
    );
}

export default ComponentOne;