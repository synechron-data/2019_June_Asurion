import React, { Component } from 'react';

// import ComponentOne from './multi-components/ComponentOne';
// import ComponentTwo from './multi-components/ComponentTwo';

// import ComponentOne from './components-with-css/CompOne/ComponentOne';
// import ComponentTwo from './components-with-css/CompTwo/ComponentTwo';

import ComponentOne from './css-modules/CompOne/ComponentOne';
import ComponentTwo from './css-modules/CompTwo/ComponentTwo';
import ComponentWithState from './ComponentWithState';
import ComponentWithProps from './ComponentWithProps';
import StatelessComponent from '../StatelessComponent';
import Button from './CompWithBehavior';
import EventComponent from './ReactEventObject';

class RootComponent extends Component {
    test(){
        alert("Test Called....");
    }

    render() {
        return (
            <div className="container">
                {/* <ComponentOne />
                <ComponentTwo /> */}
                {/* <ComponentWithState /> */}
                {/* <ComponentWithProps name={"Synechron"} empNumber={20000} city={"Pune"} display={this.test}/> */}
                {/* <StatelessComponent name={"Synechron"} empNumber={20000} city={"Pune"} state={"MH"}/> */}
                {/* <Button></Button> */}
                <EventComponent/>
            </div>
        );
    }
}

export default RootComponent;