import React, { Component } from 'react';

class ComponentWithState extends Component {
    constructor() {
        super();
        this.state = { message: "Synechron" };
        console.log("Ctor", this.state);
    }

    render() {
        console.log("render", this.state);

        return (
            <div>
                <h2>Hello, {this.state.message}</h2>
            </div>
        );
    }
}

export default ComponentWithState;