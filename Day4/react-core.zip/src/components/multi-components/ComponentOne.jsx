// import React, { Component } from 'react';

// class ComponentOne extends Component {
//     render() {
//         return (
//             <h2>Hi From Component One</h2>
//         );
//     }
// }

// export default ComponentOne;

// import React from 'react';

// const ComponentOne = () => {
//     return (
//         <h2>Hi From Component One</h2>
//     );
// }

// export default ComponentOne;

import React from 'react';

const ComponentOne = () => (
    <h2 className="text-success">Hi From Component One</h2>
);

export default ComponentOne;