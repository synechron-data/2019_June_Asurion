import React, { Component } from 'react';

class ComponentTwo extends Component {
    render() {
        return (
            <h2 className="text-info">Hi From Component Two</h2>
        );
    }
}

export default ComponentTwo;