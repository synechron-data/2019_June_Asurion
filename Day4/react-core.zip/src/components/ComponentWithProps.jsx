import React, { Component } from 'react';

class ComponentWithProps extends Component {
    constructor(props) {
        super(props);
        // this.props = { message: "Synechron" };
        // this.props.city = "Mumbai";
        console.log("Ctor, State: ", this.state);
        console.log("Ctor, Props: ", this.props);

        this.state = Object.assign({}, ...this.props);
        // this.state = {...this.props};
    }

    render() {
        console.log("render, State: ", this.state);
        console.log("render, Props: ", this.props);
        this.props.display();
        return (
            <div>
                <h2>Company Name: {this.props.name}</h2>
                <h2>City Name: {this.props.city}</h2>
            </div>
        );
    }
}

export default ComponentWithProps;