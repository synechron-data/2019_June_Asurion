// Function Declaration Syntax
// function hello() {
//     console.log("Welcome to JS World");
// }
// hello();

// Function Expression Syntax
// var n = 10;

// var hello = function () {
//     console.log("Welcome to JS World");
// }
// // hello();

// console.log(hello);
// console.log(typeof hello);


// Function Constructor Syntax
var hello = new Function('console.log("Welcome to JS World");');
hello();