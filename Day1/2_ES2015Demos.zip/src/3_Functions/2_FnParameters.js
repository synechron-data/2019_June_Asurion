// function hello(name) {
//     console.log("Welcome,", name);
// }

// hello("Manish");
// hello(23);
// hello(true);
// hello();
// hello(1,2,3,4,5,6);

// function Add(x, y) {
//     x = x || 0;
//     y = y || 0;

//     if(((typeof x) == "number") && ((typeof y) == "number"))
//         return x + y;

//     throw Error("Invalid Parameters");
// }

// console.log(Add(2, 3));
// console.log(Add(2));
// console.log(Add());
// console.log(Add(2, "ABC"));
// console.log(Add("Z", "Y"));

// ES6 - Default Parameters
// function Add(x = 0, y = 0) {
//     if (((typeof x) == "number") && ((typeof y) == "number"))
//         return x + y;

//     throw Error("Invalid Parameters");
// }

// console.log(Add(2, 4));

// ---------------------------------- Extra Params
// function hello(name) {
//     console.log("Welcome,", name);
//     console.log(arguments);
// }

// ES6 - Rest Parameters
// function hello(name, ...args) {
//     console.log("Welcome,", name);
//     console.log(args);
// }

// hello("Abhijeet");
// hello("Abhijeet", "Gole");
// hello("Abhijeet", "Gole", "Pune");

function average(...numbers) {
    console.log(numbers);
    var sum = 0;
    for (let i = 0; i < numbers.length; i++) {
        sum += numbers[i];
    }

    return sum / numbers.length;
}

// console.log(average(1));
// console.log(average(1, 2));
// console.log(average(1, 2, 3, 4, 5));
// console.log(average(1, 2, 3, 4, 5, 6, 7, 8, 9));

// var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9];
// console.log(average(...arr));   // Spread Operator (Array Spread)

var a1 = [1, 2];
// var a2 = a1;
var a2 = [...a1];


console.log(a1 == a2);