// let a = 10;
// console.log(a);

// let a = "Test";
// console.log(a);

let i = "ABC";
console.log("Before, i is", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside, i is", i);
}

console.log("After, i is", i);