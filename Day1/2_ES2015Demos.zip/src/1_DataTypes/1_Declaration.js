// var a = 10;
// console.log(a);

// var a = "Test";
// console.log(a);

// Hoisting - Hoisting is JavaScript's default behavior of moving declarations to the top.
// a = 10;
// console.log(a);
// var a;

// Scoping

var i = "ABC";
console.log("Before, i is", i);

for (var i = 0; i < 5; i++) {
    console.log("Inside, i is", i);
}

console.log("After, i is", i);