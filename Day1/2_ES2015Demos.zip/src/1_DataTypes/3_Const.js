// const env = "dev";
// console.log(env);

// // env = "prod";
// if (true) {
//     const env = "prod";
// }

const obj = { id: 1, name: "Manish", display: function () { } };
console.log(obj);
// console.log(JSON.stringify(obj));

obj.id = 10;
console.log(obj);

obj = {};