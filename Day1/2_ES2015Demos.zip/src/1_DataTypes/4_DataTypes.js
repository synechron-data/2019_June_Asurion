var language;
console.log("Language is: " + language);
console.log("Type of Language is: " + typeof language);

language = null;
console.log("Language is: " + language);
console.log("Type of Language is: " + typeof language);

language = 100;
// language = 10.5;
console.log("Language is: " + language);
console.log("Type of Language is: " + typeof language);

var max = Number.MAX_SAFE_INTEGER;
console.log(max);
console.log(max + 1);
console.log(max + 2);

// x

// language = "JS";
language = 'JS';
console.log("Language is: " + language);
console.log("Type of Language is: " + typeof language);

language = true;
console.log("Language is: " + language);
console.log("Type of Language is: " + typeof language);