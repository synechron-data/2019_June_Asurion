// import './1_DataTypes/1_Declaration';
// import './1_DataTypes/2_ES6_Declarations';
// import './1_DataTypes/3_Const';
// import './1_DataTypes/4_DataTypes';

// import './2_Operators/1_Equility';
// import './2_Operators/2_DataConversion';

// import './3_Functions/1_FnCreation';
import './3_Functions/2_FnParameters';