// var age = window.prompt("What is your age?");
// document.write("Age is: " + age + "<br/>");

// var a1 = age + 10;
// document.write("a1 is: " + a1 + "<br/>");

// var a2 = parseInt(age) + 10;
// document.write("a2 is: " + a2 + "<br/>");

// var a3 = parseFloat(age) + 10;
// document.write("a3 is: " + a3 + "<br/>");

// var a4 = Number(age) + 10;
// document.write("a4 is: " + a4 + "<br/>");

// document.write(Boolean(1) + "<br/>");
// document.write(Boolean(0) + "<br/>");
// document.write(Boolean(-1) + "<br/>");
// document.write(Boolean("") + "<br/>");
// document.write(Boolean("ABC") + "<br/>");
// document.write(Boolean(undefined) + "<br/>");
// document.write(Boolean(null) + "<br/>");

// var obj = "";

// if (!obj) {
//     document.write("Is Null");
// } else {
//     document.write("Is not Null");
// }

console.log(true && "ABC" || "XYZ");
console.log(false && "ABC" || "XYZ");