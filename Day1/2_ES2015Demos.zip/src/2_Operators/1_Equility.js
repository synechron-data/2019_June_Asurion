var a = 54;
var b = "54";

// console.log(typeof a);
// console.log(typeof b);

var r1 = a == b;
console.log(r1);

var r1 = a === b;
console.log(r1);