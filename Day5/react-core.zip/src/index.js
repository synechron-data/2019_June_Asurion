import React from 'react';
import ReactDOM from 'react-dom';
import RootComponent from './components/RootComponent';
import $ from 'jquery';
import 'bootstrap/scss/bootstrap.scss';

window.$ = $;
window.jQuery = $;
global.jQuery = $;

// eslint-disable-next-line
const bootstrap = require('bootstrap');

ReactDOM.render(<RootComponent />, document.getElementById('root'));