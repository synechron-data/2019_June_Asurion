import React, { Component } from 'react';
import TextInput from './shared/TextInput';
import DataTable from './shared/DataTable';

class FormComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { id: "", name: "", designation: "", salary: "" };
        this.updateState = this.updateState.bind(this);
        this.save = this.save.bind(this);
    }

    updateState(e) {
        const field = e.target.id;
        var newState = Object.assign({}, this.state);
        newState[field] = e.target.value;
        this.setState(newState);
    }

    save(e) {
        e.preventDefault();
        this.props.onSave(this.state);
    }

    render() {
        return (
            <div className="row">
                <div className="col-sm-6 offset-sm-3">
                    <form className="justify-content-center" onSubmit={this.save}>
                        <fieldset>
                            <legend className="text-center">Add Employee Form Component</legend>
                            <TextInput label={"Id"} name={"id"} onChange={this.updateState} />
                            <TextInput label={"Name"} name={"name"} onChange={this.updateState} />
                            <TextInput label={"Designation"} name={"designation"} onChange={this.updateState} />
                            <TextInput label={"Salary"} name={"salary"} onChange={this.updateState} />

                            <div className="row">
                                <div className="col-sm-6">
                                    <button type="submit" className="btn btn-success btn-block">Save</button>
                                </div>
                                <div className="col-sm-6">
                                    <button type="reset" className="btn btn-primary btn-block">Reset</button>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        );
    }
}

class FormAssignment extends Component {
    constructor(props) {
        super(props);
        this.state = {
            employees: []
        };
        this.addEmployee = this.addEmployee.bind(this);
    }

    addEmployee(employee) {
        // this.setState({ employees: this.state.employees.concat({...employee}) });
        this.setState({ employees: [...this.state.employees, { ...employee }] });
    }

    render() {
        return (
            <React.Fragment>
                <FormComponent onSave={this.addEmployee} />
                <hr />
                <DataTable items={this.state.employees}>
                    <h3 className="text-success">Employees Table</h3>
                </DataTable>
            </React.Fragment>
        );
    }
}

export default FormAssignment;