import React, { Component } from 'react';

class CalculatorOne extends Component {
    constructor(props) {
        super(props);
        this.state = { data: { t1: 0, t2: 0 }, result: 0 };
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleSubmit(e) {
        e.preventDefault();
        this.setState({ result: parseInt(this.refs.t1.value) + parseInt(this.refs.t2.value) });
    }

    render() {
        return (
            <div className="row">
                <div className="col-sm-6 offset-sm-3">
                    <form className="justify-content-center" onSubmit={this.handleSubmit}>
                        <fieldset>
                            <legend className="text-center">Calculator Assignment</legend>
                            <div className="form-group">
                                <label htmlFor="t1">Number One</label>
                                <input type="text" className="form-control" id="t1" ref="t1"
                                    defaultValue={this.state.data.t1} />
                            </div>
                            <div className="form-group">
                                <label htmlFor="t2">Number Two</label>
                                <input type="text" className="form-control" id="t2" ref="t2"
                                    defaultValue={this.state.data.t2} />
                            </div>
                            <div className="form-group">
                                <h3>Result: {this.state.result}</h3>
                            </div>
                            <div className="form-group">
                                <button type="submit" className="btn btn-success btn-block">Add</button>
                                <button type="reset" className="btn btn-primary btn-block">Reset</button>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        );
    }
}

class CalculatorTwo extends Component {
    constructor(props) {
        super(props);
        this.state = { data: { t1: 0, t2: 0 }, result: 0 };
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange1 = this.handleChange1.bind(this);
        this.handleChange2 = this.handleChange2.bind(this);
    }

    handleSubmit(e) {
        e.preventDefault();
        this.setState({ result: parseInt(this.state.data.t1) + parseInt(this.state.data.t2) });
    }

    handleChange1(e) {
        var obj = { ...this.state.data };
        obj.t1 = e.target.value;
        this.setState({ data: obj });
    }

    handleChange2(e) {
        var obj = { ...this.state.data };
        obj.t2 = e.target.value;
        this.setState({ data: obj });
    }

    render() {
        return (
            <div className="row">
                <div className="col-sm-6 offset-sm-3">
                    <form className="justify-content-center" onSubmit={this.handleSubmit}>
                        <fieldset>
                            <legend className="text-center">Calculator Assignment</legend>
                            <div className="form-group">
                                <label htmlFor="t1">Number One</label>
                                <input type="text" className="form-control" id="t1"
                                    value={this.state.data.t1} onChange={this.handleChange1} />
                            </div>
                            <div className="form-group">
                                <label htmlFor="t2">Number Two</label>
                                <input type="text" className="form-control" id="t2"
                                    value={this.state.data.t2} onChange={this.handleChange2} />
                            </div>
                            <div className="form-group">
                                <h3>Result: {this.state.result}</h3>
                            </div>
                            <div className="form-group">
                                <button type="submit" className="btn btn-success btn-block">Add</button>
                                <button type="reset" className="btn btn-primary btn-block">Reset</button>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        );
    }
}

class CalculatorThree extends Component {
    constructor(props) {
        super(props);
        this.state = { data: { t1: 0, t2: 0 }, result: 0 };
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    handleSubmit(e) {
        e.preventDefault();
        this.setState({ result: parseInt(this.state.data.t1) + parseInt(this.state.data.t2) });
    }

    handleChange(e) {
        const field = e.target.id;
        var obj = { ...this.state.data };
        obj[field] = e.target.value;
        this.setState({ data: obj });
    }

    render() {
        return (
            <div className="row">
                <div className="col-sm-6 offset-sm-3">
                    <form className="justify-content-center" onSubmit={this.handleSubmit}>
                        <fieldset>
                            <legend className="text-center">Calculator Assignment</legend>
                            <div className="form-group">
                                <label htmlFor="t1">Number One</label>
                                <input type="text" className="form-control" id="t1"
                                    value={this.state.data.t1} onChange={this.handleChange} />
                            </div>
                            <div className="form-group">
                                <label htmlFor="t2">Number Two</label>
                                <input type="text" className="form-control" id="t2"
                                    value={this.state.data.t2} onChange={this.handleChange} />
                            </div>
                            <div className="form-group">
                                <h3>Result: {this.state.result}</h3>
                            </div>
                            <div className="form-group">
                                <button type="submit" className="btn btn-success btn-block">Add</button>
                                <button type="reset" className="btn btn-primary btn-block">Reset</button>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        );
    }
}

const TextInput = (props) => {
    return (
        <div className="form-group">
            <label htmlFor={props.name}>{props.label}</label>
            <input type="number" className="form-control" id={props.name} name={props.name}
                value={props.value} onChange={props.onChange} />
        </div>
    );
}

class CalculatorFour extends Component {
    constructor(props) {
        super(props);
        this.state = { data: { t1: 0, t2: 0 }, result: 0 };
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    handleSubmit(e) {
        e.preventDefault();
        this.setState({ result: parseInt(this.state.data.t1) + parseInt(this.state.data.t2) });
    }

    handleChange(e) {
        const field = e.target.id;
        var obj = { ...this.state.data };
        obj[field] = e.target.value;
        this.setState({ data: obj });
    }

    render() {
        return (
            <div className="row">
                <div className="col-sm-6 offset-sm-3">
                    <form className="justify-content-center" onSubmit={this.handleSubmit}>
                        <fieldset>
                            <legend className="text-center">Calculator Assignment</legend>
                            <TextInput label={"Number One"} name={"t1"} onChange={this.handleChange}
                                value={this.state.data.t1} />

                            <TextInput label={"Number Two"} name={"t2"} onChange={this.handleChange}
                                value={this.state.data.t2} />

                            <div className="form-group">
                                <h3>Result: {this.state.result}</h3>
                            </div>
                            <div className="form-group">
                                <button type="submit" className="btn btn-success btn-block">Add</button>
                                <button type="reset" className="btn btn-primary btn-block">Reset</button>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        );
    }
}

class CalculatorAssignment extends Component {
    render() {
        return (
            // <CalculatorOne />
            // <CalculatorTwo />
            // <CalculatorThree/>
            <CalculatorFour />
        );
    }
}

export default CalculatorAssignment;