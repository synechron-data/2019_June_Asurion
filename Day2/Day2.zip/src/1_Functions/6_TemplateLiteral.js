var name = "Manish";
var message = "How are you?";

// ES 5
var fMsg = "Hello " + name + ", " + message;
console.log(fMsg);

// ES 2015
var fMsg1 = `Hello ${name}, ${message}`;
console.log(fMsg1);


var x = 10;
var y = 20;

var msg = "x = " + x + ", \ny = " + y;
console.log(msg);

var msg1 = `x = ${x}, 


                    y = ${y}`;
console.log(msg1);