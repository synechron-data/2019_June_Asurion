// function Add1(x, y) {
//     return x + y;
// }

// var Add2 = function (x, y) {
//     return x + y;
// }

// var Add3 = (x, y) => {
//     return x + y;
// }

// var Add4 = (x, y) => x + y;

// console.log(Add1(2, 3));
// console.log(Add2(2, 3));
// console.log(Add3(2, 3));
// console.log(Add4(2, 3));

// document.getElementById("b1").addEventListener("click",() => {

// })

// $("#b1").click(() => {

// })

// setInterval(() => {
//     console.log("First");
// }, 2000);

// Dev 1
// function getString(cb) {
//     const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];

//     setInterval(function () {
//         var str = strArr[Math.floor(Math.random() * strArr.length)];
//         cb(str);
//     }, 2000);
// }

// // Dev 2
// getString((s) => {
//     console.log(s);
// });

var arr = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Abhijeet" },
    { id: 3, name: "Pravin" }
];


function Search(item) {
    return item.id == 2;
}

var result1 = arr.find(Search);
console.log(result1);

var result2 = arr.find(function (item) {
    return item.id == 2;
});
console.log(result2);

var result3 = arr.find((item) => {
    return item.id == 2;
});
console.log(result3);

var result4 = arr.find(item => item.id == 2);
console.log(result4);