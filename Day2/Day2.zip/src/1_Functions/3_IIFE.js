

// function hello(name) {
//     console.log("Hello,", name);
// }

// hello("Abhijeet");

// IIFE - Immediatly Invoked Function Expression
// (function (name) {
//     console.log("Hello,", name);
// })("Abhijeet");

var i = "ABC";
console.log("Before, i is", i);

(function (){
    for (var i = 0; i < 5; i++) {
        console.log("Inside, i is", i);
    }
})();

(() => {
    for (var i = 0; i < 5; i++) {
        console.log("Inside, i is", i);
    }
})();

console.log("After, i is", i);