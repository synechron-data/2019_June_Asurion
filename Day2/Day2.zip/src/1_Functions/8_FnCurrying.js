function greetings(message, name) {
    console.log(`${message}, ${name}`);
}

// greetings("Good Morning", "Abhijeet");
// greetings("Good Morning", "Ramakant");
// greetings("Good Morning", "Pravin");

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(' km', 1.6, 0, 20));
// console.log(Converter(' km', 1.6, 0, 30));
// console.log(Converter(' km', 1.6, 0, 40));
// console.log(Converter(' km', 1.6, 0, 50));

// var mGreet = greetings.bind(this, "Good Morning");
// mGreet("Abhijeet")
// mGreet("Ramakant")
// mGreet("Pravin")

function Converter(toUnit, factor, offset) {
    return function (input)
    {
        return [((offset + input) * factor).toFixed(2), toUnit].join("");
    }
}

// var MilesToKm = Converter.bind(this, ' km', 1.6, 0);
var MilesToKm = Converter(' km', 1.6, 0);
console.log(MilesToKm(20));
console.log(MilesToKm(30));
console.log(MilesToKm(40));
console.log(MilesToKm(50));