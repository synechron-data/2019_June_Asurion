// document.getElementById("b1").addEventListener("click",function(){

// })

// $("#b1").click(function(){

// })

// setInterval(function () {
//     console.log("First");
// }, 2000);

// setInterval(function () {
//     console.log("Second");
// }, 2000);

// function getString() {
//     const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];
//     var str = strArr[Math.floor(Math.random() * strArr.length)];
//     return str;
// }

// console.log(getString());
// console.log(getString());
// console.log(getString());
// console.log(getString());

// setInterval(function () {
//     console.log(getString());
// }, 2000);

// Dev 1
function getString(cb) {
    const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];

    setInterval(function () {
        var str = strArr[Math.floor(Math.random() * strArr.length)];
        cb(str);
    }, 2000);
}

// Dev 2
getString(function (s) {
    console.log(s);
});