// Case 1 - Default Export
// export default function square(x) {
//     return x * x;
// }

// // Case 2 - Named Export
// export function square(x) {
//     return x * x;
// }

// export function check(x) {
//     return "checked " + x;
// }

// Case 3 - Named Export & Default
export default function square(x) {
    return x * x;
}

export function check(x) {
    return "checked " + x;
}