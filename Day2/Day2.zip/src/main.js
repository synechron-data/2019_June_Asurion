import '../public/favicon.ico';

// import './1_Functions/1_Callbacks';
// import './1_Functions/2_ArrowFn';
// import './1_Functions/3_IIFE';
// import './1_Functions/4_FnOverloading';
// import './1_Functions/5_Closure';
// import './1_Functions/6_TemplateLiteral';
// import './1_Functions/7_FnInvocation';
// import './1_Functions/8_FnCurrying';

// import './2_Types/1_ObjectCreation';
// import './2_Types/2_ObjectType';
// import './2_Types/3_CustomType';
// import './2_Types/4_UsingPrototype';
// import './2_Types/5_Assignment';
// import './2_Types/6_Classes';
// import './2_Types/7_Compare';
// import './2_Types/8_ES5_Properties';
// import './2_Types/9_ES6_Properties';
// import './2_Types/10_ObjectMethods';
// import './2_Types/11_ES5Inheritance';
// import './2_Types/12_ES6Inheritance';

import './3_Modules/usage';
