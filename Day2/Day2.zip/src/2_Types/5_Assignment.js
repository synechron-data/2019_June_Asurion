const Counter = (function () {
    function Counter(by) {
        this._count = 0;
        this._by = by;
    }

    Counter.prototype.next = function () {
        return this._count += this._by;
    }

    Counter.prototype.prev = function () {
        return this._count -= this._by;
    }

    return Counter;
})();

var counter = new Counter(1);
console.log(counter.next());
console.log(counter.next());

console.log("\n");
var counter5 = new Counter(5);
console.log(counter5.next());
console.log(counter5.next());