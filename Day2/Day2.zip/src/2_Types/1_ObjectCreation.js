// var obj = null;
// var obj = new Object();

// Object Literal
// var obj = {};
// console.log(obj);
// console.log(typeof obj);

var person = {
    id: 1,
    name: "Manish",
    city: "Pune",
    display: function () {
        console.log(this);
    }
};

console.log(person);
