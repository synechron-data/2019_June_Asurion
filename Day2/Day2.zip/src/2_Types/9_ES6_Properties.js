class Person {
    constructor(name = "NA", age = 0) {
        this._name = name;
        this._age = age;
    }

    get Name() {
        return this._name;
    }

    set Name(name) {
        this._name = name;
    }

    get Age() {
        return this._age;
    }
}

var p1 = new Person("Manish");
console.log(p1.Name);
p1.Name = "Abhijeet";
console.log(p1.Name);

// p1.Age = 36;
console.log(p1.Age);