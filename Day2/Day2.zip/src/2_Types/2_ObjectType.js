var toy1 = new Object();
// toy1.toString = function(){
//     return ("Just for Test");
// };

// console.log(toy1.toString());
// console.log(Object.prototype);
// toy1.color = "red";

Object.prototype.color = "red";
toy1.color = "blue";

console.log(toy1.color);
var toy2 = new Object();
console.log(toy2.color);
