// let target = { a: 1, b: 2 };
// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// let obj = Object.assign({}, source);  // Shallow Copy
// // let obj = source;

// // console.log(obj === source);

// // obj.id = 10;
// obj.address.city = "Mumbai";

// console.log(source);
// console.log(obj);

// let obj = JSON.parse(JSON.stringify(source));
// obj.address.city = "Mumbai";

// console.log(source);
// console.log(obj);

// let obj = Object.assign(target, source);
// console.log(obj);

// -------------------------------------------  Object.create
//  Creates a new object, using an existing object as the prototype of the newly created object.
// const newSource = Object.create(source);
// console.log("Source: ", source);
// console.log("New Source: ", newSource);

// ------------------------------------------- Object.freeze
let source = { id: 1, name: "Manish" };

// Object.freeze(source);
// Object.preventExtensions(source);

console.log(source);
console.log(Object.isExtensible(source));

if (Object.isExtensible(source))
    source.city = "Pune";

// source.name = "Abhijeet";
// source.city = "Pune";
console.log(source);
