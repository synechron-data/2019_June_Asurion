import React, { Component } from 'react';

class AdminComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { products: [], message: "Loading Data, please wait..." };
    }

    render() {
        return (
            <div>
                <h1 className="text-info">Admin Component</h1>
                <h4 className="text-success">Welcome, you are an authenticated user.</h4>
            </div>
        );
    }
}

export default AdminComponent;