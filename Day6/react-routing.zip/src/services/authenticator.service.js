const url = "http://localhost:8000/api/authenticate";

export const authenticator = {
    isAuthenticated: false,
    
    login: function (uname, pwd, loginSuccess, loginFailed) { 

    },
    
    logout: function () { 
        window.sessionStorage.clear();
        this.isAuthenticated = false;
    },

    getToken: function () { 
        return window.sessionStorage("tk");
    }
};