import 'bootstrap/scss/bootstrap.scss';

import React from 'react';
import ReactDOM from 'react-dom';
import $ from 'jquery';
import RootComponent from './components/root/RootComponent';
import { BrowserRouter } from 'react-router-dom';

window.$ = $;
window.jQuery = $;
global.jQuery = $;

// eslint-disable-next-line
const bootstrap = require('bootstrap');

ReactDOM.render(
    <BrowserRouter>
        <RootComponent />
    </BrowserRouter>, document.getElementById('root'));