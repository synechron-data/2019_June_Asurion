import React, { Component } from 'react';
import DataTable from './shared/DataTable';
import postClientAPI from '../services/post.service';

class AjaxDemo extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], message: "Loading data, please wait..." };
    }

    render() {
        return (
            <React.Fragment>
                <div className="row">
                    <h3 className="text-warning">{this.state.message}</h3>
                </div>
                <DataTable items={this.state.posts}>
                    <h4 className="text-success">Posts Table</h4>
                </DataTable>
            </React.Fragment>
        );
    }

    componentDidMount() {
        postClientAPI.getAllPosts().then((data) => {
            this.setState({ posts: [...data], message: "" });
        }, (eMsg) => {
            this.setState({ message: eMsg });
        });
    }
}

export default AjaxDemo;