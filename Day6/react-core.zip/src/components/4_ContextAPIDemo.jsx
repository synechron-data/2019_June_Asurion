import React, { Component } from 'react';
import DataTable from './shared/DataTable';
import postClientAPI from '../services/post.service';

const { Provider, Consumer } = React.createContext();

class ContextAPIDemo extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], message: "Loading data, please wait..." };
    }

    render() {
        return (
            <React.Fragment>
                <div className="row">
                    <h3 className="text-warning">{this.state.message}</h3>
                </div>
                <Provider value={this.state.posts}>
                    <ChildOneComponent />
                </Provider>
            </React.Fragment>
        );
    }

    componentDidMount() {
        postClientAPI.getAllPosts().then((data) => {
            this.setState({ posts: [...data], message: "" });
        }, (eMsg) => {
            this.setState({ message: eMsg });
        });
    }
}

class ChildOneComponent extends Component {
    render() {
        return (
            <div>
                <ChildTwoComponent />
            </div>
        );
    }
}

class ChildTwoComponent extends Component {
    render() {
        return (
            <div>
                <Consumer>
                    {
                        (data) =>
                            <DataTable items={data}>
                                <h4 className="text-success">Posts Table</h4>
                            </DataTable>
                    }
                </Consumer>
            </div>
        );
    }
}

export default ContextAPIDemo;