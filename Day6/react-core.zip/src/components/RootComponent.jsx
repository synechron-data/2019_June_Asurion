import React, { Component } from 'react';
import PTRoot from './1_PropTypesDemo';
import ErrorHandler from './shared/ErrorHandler';
import AjaxDemo from './2_AjaxDemo';
import PropDrillingDemo from './3_PropDrilling';
import ContextAPIDemo from './4_ContextAPIDemo';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    {/* <PTRoot /> */}
                    {/* <AjaxDemo /> */}
                    {/* <PropDrillingDemo/> */}
                    <ContextAPIDemo />
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;