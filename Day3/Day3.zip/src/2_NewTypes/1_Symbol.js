// const COLOR_RED = 'RED';
// const COLOR_ORANGE = 'ORANGE';
// const COLOR_YELLOW = 'YELLOW';
// const COLOR_GREEN = 'GREEN';
// const COLOR_BLUE = 'BLUE';
// const COLOR_VIOLET = 'VIOLET';

// function get(color) {
//     switch (color) {
//         case COLOR_RED:
//             return COLOR_GREEN;
//         case COLOR_ORANGE:
//             return COLOR_BLUE; 
//         case COLOR_YELLOW:
//             return COLOR_VIOLET; 
//         case COLOR_GREEN:
//             return COLOR_RED; 
//         case COLOR_BLUE:
//             return COLOR_ORANGE; 
//         case COLOR_VIOLET:
//             return COLOR_YELLOW;
//         default:
//             return ('Unknown Color')
//     }
// }

// console.log(get(COLOR_RED));
// console.log(get('BLUE'));

// var x = "ABC";
// var y = "ABC";

// console.log(x == y);
// console.log(x === y);

// var x = Symbol("ABC");
// var y = Symbol("ABC");

// console.log(x == y);
// console.log(x === y);

// --------------------------------------------

const COLOR_RED = Symbol('RED');
const COLOR_ORANGE = Symbol('ORANGE');
const COLOR_YELLOW = Symbol('YELLOW');
const COLOR_GREEN = Symbol('GREEN');
const COLOR_BLUE = Symbol('BLUE');
const COLOR_VIOLET = Symbol('VIOLET');

function get(color) {
    switch (color) {
        case COLOR_RED:
            return COLOR_GREEN;
        case COLOR_ORANGE:
            return COLOR_BLUE;
        case COLOR_YELLOW:
            return COLOR_VIOLET;
        case COLOR_GREEN:
            return COLOR_RED;
        case COLOR_BLUE:
            return COLOR_ORANGE;
        case COLOR_VIOLET:
            return COLOR_YELLOW;
        default:
            return ('Unknown Color')
    }
}

// console.log(get(COLOR_RED));
// console.log(get('BLUE'));
// console.log(get(Symbol('BLUE')));

const idKey = Symbol();

const obj = { [idKey]: 123, name: "ABC" };
// console.log(obj.idKey);
// console.log(obj[idKey]);
// console.log(obj.name);
// console.log(obj[name]);

console.log(obj);
console.log(JSON.stringify(obj));
