class Queue {
    constructor() {
        this._dataArray = [];
    }

    push(data) {
        this._dataArray.push(data);
    }

    pop() {
        return this._dataArray.shift();
    }

    // Generators
    *[Symbol.iterator]() {
        yield* this._dataArray;
    }

    // Generators
    // *[Symbol.iterator]() {
    //     for (let i = 0; i < this._dataArray.length; i++) {
    //         yield this._dataArray[i];
    //     }
    // }

    // [Symbol.iterator]() {
    //     const self = this;
    //     let i = 0;

    //     return {
    //         next: function () {
    //             let v, d = true;

    //             if (self._dataArray[i] !== undefined) {
    //                 v = self._dataArray[i];
    //                 d = false;
    //                 i += 1;
    //             }

    //             return {
    //                 value: v,
    //                 done: d
    //             }
    //         }
    //     }
    // }
}

var q = new Queue();

q.push(1);
q.push(2);
q.push(3);

// console.log(q.pop());
// console.log(q.pop());
// console.log(q.pop());

for (const item of q) {
    console.log(item);
}