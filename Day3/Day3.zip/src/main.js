import '../public/favicon.ico';

// import './1_Collections/1_Arrays';
// import './1_Collections/2_Map';
// import './1_Collections/3_Set';

// import './2_NewTypes/1_Symbol';
// import './2_NewTypes/2_CustomCollection';

// import './3_Promise/1_CustomPromise';
// import './3_Promise/2_PromiseChaning';
// import './3_Promise/3_PromiseMethods';
import './3_Promise/5_Usage';
