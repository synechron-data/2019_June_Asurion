import localAPI from "./4_LocalAPI";

// localAPI.getAllPosts((data) => {
//     console.log("Usage - ", data);
// }, (eMsg) => {
//     console.error("Usage - ", eMsg);
// });

// localAPI.getAllPostsUsingPromise().then((data) => {
//     console.log("Usage - ", data);
// }, (eMsg) => {
//     console.error("Usage - ", eMsg);
// });

(async function () {
    var data = await localAPI.getPosts();
    console.log("Usage - ", data);
})();