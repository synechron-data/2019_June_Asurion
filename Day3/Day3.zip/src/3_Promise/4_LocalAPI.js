const url = "https://jsonplaceholder.typicode.com/posts";

const localAPI = {
    getAllPosts(successCB, errorCB) {
        fetch(url).then((response) => {
            response.json().then((data) => {
                successCB(data);
            }, (err) => {
                errorCB("Parsing Error");
            })
        }, (err) => {
            errorCB("Communication Error");
        })
    },

    getAllPostsUsingPromise() {
        let promise = new Promise((resolve, reject) => {
            fetch(url).then((response) => {
                response.json().then((data) => {
                    resolve(data);
                }, (err) => {
                    reject("Parsing Error");
                })
            }, (err) => {
                reject("Communication Error");
            })
        });
        return promise;
    },

    async getPosts() {
        var response = await fetch(url);
        var data = await response.json();
        return data;
    }
};

export default localAPI;