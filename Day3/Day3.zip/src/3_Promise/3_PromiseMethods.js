// var firstMethod = function () {
//     var promise = new Promise(function (resolve, reject) {
//         setTimeout(function () {
//             console.log('first method completed');
//             resolve({ firstdata: '1' });
//         }, 2000);
//     });
//     return promise;
// };


// var secondMethod = function () {
//     var promise = new Promise(function (resolve, reject) {
//         setTimeout(function () {
//             console.log('second method completed');
//             resolve({ seconddata: '2' });
//         }, 2000);
//     });
//     return promise;
// };

// var thirdMethod = function () {
//     var promise = new Promise(function (resolve, reject) {
//         setTimeout(function () {
//             console.log('third method completed');
//             resolve({ thirddata: '2' });
//         }, 3000);
//     });
//     return promise;
// };

// Promise.all([firstMethod(), secondMethod(), thirdMethod()]).then(data => { console.log(data) });

// ---------------------------------

var firstMethod = function () {
    var promise = new Promise(function (resolve, reject) {
        setTimeout(function () {
            console.log('first method completed');
            resolve({ firstdata: '1' });
        }, 2000);
    });
    return promise;
};


var secondMethod = function () {
    var promise = new Promise(function (resolve, reject) {
        setTimeout(function () {
            console.log('second method completed');
            resolve({ seconddata: '2' });
        }, 2000);
    });
    return promise;
};

var thirdMethod = function () {
    var promise = new Promise(function (resolve, reject) {
        setTimeout(function () {
            console.log('third method completed');
            resolve({ thirddata: '2' });
        }, 3000);
    });
    return promise;
};

Promise.race([firstMethod(), secondMethod(), thirdMethod()]).then(data => { console.log(data) });