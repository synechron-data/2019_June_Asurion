// Dev 1
var promise = new Promise((resolve, reject) => {
    setTimeout(function () {
        // resolve("It is a success");
        reject("This is a rejection");
    }, 4000);
});

// Dev 2
// promise.then((msg) => {
//     console.log(msg)
// }, (eMsg) => {
//     console.error(eMsg);
// });

// promise.then((msg) => {
//     console.log(msg)
// }).catch((eMsg) => {
//     console.error(eMsg);
// });

promise.then((msg) => {
    console.log(msg);
}).catch((eMsg) => {
    console.error(eMsg);
}).finally(()=>{
    console.log("I will run always..");
});

// Arrange
// Act - Call and get the output
// Assert

function logic1(x, y) {
    var sum = x + y;  // Long Running Logic
    return (sum);
}

function logic2(x, y, cb) {
    var sum = x + y;
    cb(sum);
}

function logic3(x, y) {
    var promise = new Promise((resolve, reject) => {
        var sum = x + y;

    });
    return promise;
}