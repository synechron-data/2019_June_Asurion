// var set = new Set();

// set.add(1);
// set.add(2);
// set.add(3);
// set.add(4);
// set.add(2);

// for (const item of set) {
//     console.log(item);
// }

var set = new Set();

var varun =  { id: 2, name: "Varun" };

set.add({ id: 1, name: "Manish" });
set.add({ id: 1, name: "Manish" });
set.add(varun);
set.add(varun);

for (const item of set) {
    console.log(item);
}