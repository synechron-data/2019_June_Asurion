var myMap = new Map();

// console.log(myMap);
// console.log(typeof myMap);
// console.log(myMap.size);

var objRef = {};
var fnRef = function () { };

myMap.set('the string', "This is a value for string key");
myMap.set(objRef, "This is a value for object key");
myMap.set(fnRef, "This is a value for function key");

// console.log(myMap.get('the string'));
// console.log(myMap.get(objRef));
// console.log(myMap.get(fnRef));
// console.log(myMap.size);

// for (const pair of myMap) {
//     console.log(pair);
// }

// for (const key of myMap.keys()) {
//     console.log(key);
// }

// for (const value of myMap.values()) {
//     console.log(value);
// }

// for (const [key, value] of myMap.entries()) {
//     console.log(key + "\t - " + value);
// }

for (const [key, value] of myMap) {
    console.log(key + "\t - " + value);
}

// Array Destructuring
// var arr = [10, 20, 30, 40, 50];
// var x = arr[0];
// var y = arr[1];
// var [x, , y] = arr;

// console.log(x, y);

// var [x, , y] = arr;
// console.log(`Before x = ${x}, y = ${y}`);

// [x, y] = [y, x];

// console.log(`After x = ${x}, y = ${y}`);

// Object Destructuring
// var obj = { id: 1, name: "Manish", city: "Pune" };

// // var id = obj.id;
// // var name = obj.name;

// var { id, name } = obj;
// // import {square, check} from '.\file';

// console.log(id, name);

// function display(args){
//     console.log(args);
// }

// function display({ name, city }) {
//     console.log(name);
//     console.log(city);
// }

// ------------------------------------------------- Will see later
// function display({ id, name, ...address }) {
//     console.log(id);
//     console.log(name);
//     console.log(address);
// }

// display({ id: 1, name: "Manish", city: "Pune", zip: 411021 });

// function display(id, name, city, zip) {
//     console.log(id);
//     console.log(name);
//     console.log(city);
//     console.log(zip);
// }

// var emp = { id: 1, name: "Manish", city: "Pune", zip: 411021 };
// display({...emp});