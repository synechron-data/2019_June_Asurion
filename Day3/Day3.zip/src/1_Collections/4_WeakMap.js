var map = new Map();
var wmap = new WeakMap();

(function () {
    var a = { a: 1 };
    var b = { b: 2 };

    map.set(a, "This is Map");
    wmap.set(b, "This is Weak Map");
})();