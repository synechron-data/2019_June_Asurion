// var employees = new Array();
// var employees = new Array(2);
// var employees = [];
// console.log(employees.length);

// var employees = new Array(2);
// employees[0] = "Manish";
// employees[4] = "Abhijeet";

// for (let i = 0; i < employees.length; i++) {
//     console.log(i + "\t" + employees[i]);
// }

// console.log(employees[5]);

// var employees = [
//     { id: 1, name: "Manish" },
//     { id: 2, name: "Varun" },
//     { id: 3, name: "Paresh" },
//     { id: 4, name: "Devesh" },
//     { id: 5, name: "Atul" },
// ];

// for (let i = 0; i < employees.length; i++) {
//     console.log(i + "\t" + employees[i].id + "\t" + employees[i].name);
// }

// console.log(typeof employees);

// for(const key in employees){
//     console.log(key + "\t" + employees[key].id + "\t" + employees[key].name);
// }

var obj = { id: 1, name: "Manish", city: "Pune" };

for (const key in obj) {
    console.log(key);
    console.log(obj[key]);
}

// console.log(Object.keys(obj));

// // Object.keys(obj).forEach((item)=>{
// //     console.log(item.toUpperCase());
// // });

// var arr = Object.keys(obj).map((item)=>{
//     return (`<th>${item.toUpperCase()}</th>`);
// });

// console.log(arr);

// var obj1 = Object.create(obj);
// // var obj1 = Object.assign(obj);

// for (const key in obj1) {
//     console.log(key);
// }

// // console.log(obj1);
// Object.keys(obj1).forEach((item)=>{
//     console.log(item.toUpperCase());
// });

// var employees = [
//     { id: 1, name: "Manish" },
//     { id: 2, name: "Varun" },
//     { id: 3, name: "Paresh" },
//     { id: 4, name: "Devesh" },
//     { id: 5, name: "Atul" },
// ];

// for (const item of employees) {
//     console.log(item.id + "\t" + item.name);
// }

// var states = new Array();

// states["GA"] = "Goa";
// states["DL"] = "Delhi";
// states["MH"] = "Maharashtra";

// for(const key in states){
//     console.log(key + "\t" + states[key]);
// }